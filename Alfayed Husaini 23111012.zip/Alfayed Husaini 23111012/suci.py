data"""program studi S1-sistem informasi
fakultas ilmu komputer
universitas nurdin hamzah """
def kampus():
    print(data)

x="""nim  :25111042
nama    :suci ramadani
alamat  :tebo"""
def biodata():
    print(x)

    img,alt,title,